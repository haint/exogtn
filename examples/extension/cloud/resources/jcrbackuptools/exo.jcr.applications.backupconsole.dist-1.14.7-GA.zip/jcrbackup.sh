#!/bin/sh

java -jar exo.jcr.applications.backupconsole.dist-binary.jar $*
